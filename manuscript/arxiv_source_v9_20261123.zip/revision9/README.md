# Reference-answerability review and post hoc sensitivity

The review procedure and use of assistance are described in the manuscript.
The original references, scores and all-24-task primary results are preserved.
The three-task exclusion was fixed from answerability concerns before subset
effects were calculated, after the full-sample results and responses were known.
A further post hoc analysis retains the 15 author-reviewed category A tasks;
these are not independently adjudicated labels. The full 24 tasks remain primary.

reference_review.json records all item classifications, reasons and table
hashes. sensitivity_plan.json identifies the fixed exclusions. The CSV and
JSON files report all endpoint contrasts and paired-task intervals.

To reproduce the sensitivity analysis, run reference_sensitivity.py with
--scores pointing to validation/results/trial_scores.csv from the public study
archive, --review pointing to reference_review.json, --plan pointing to
sensitivity_plan.json, and --output pointing to the desired result directory.
The script requires Python and NumPy and leaves source scores unchanged.
clean_correction_transitions.csv records the policy-specific clean-correct
subsets and their observed correction outcomes. These are descriptive transitions.
