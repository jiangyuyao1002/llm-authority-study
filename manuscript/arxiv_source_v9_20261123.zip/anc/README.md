# Ancillary files

Reproduce all stored scores offline:

    python -m pip install -r requirements.txt
    python analyze.py

Full frozen dataset:
https://github.com/jiangyuyao1002/llm-authority-study
