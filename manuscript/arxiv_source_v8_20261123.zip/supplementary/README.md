# Supplementary file index

These files accompany the manuscript and retain the values in the analysis records.

- Supplementary File S1: S1_benchmark_audit_manifest.json (pinned benchmark source audit).
- Supplementary File S2: S2_edge_responses.json (the two retained schema-invalid responses).
- Supplementary File S3: S3_reference_sensitivity.csv (all 24/21/15-task estimates).

The original analysis records and recomputation scripts remain in the source archive.
